const mongoose = require("mongoose");

let URI = process.env.MONGODB_URI ;

mongoose.connect( URI , {
    //  useNewUrlParser:true,
    // useUnifiedTopology:true
}).then(() => {
    console.log("Connection successful !!")
}).catch((e) => {
    console.log("Not Connected !!")
})